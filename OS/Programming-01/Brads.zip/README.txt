Hi,

To compile my program use:

gcc --std=c99 -lpthread McCoy-460-Programming-01.c -o brad

to run use:

 ./brad

 My code is not efficient as we only allow one car at a
 time on the oneway.

 The code was tested by using many different print statements
 that told me what was happening.
